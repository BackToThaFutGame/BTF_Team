﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Teacher : MonoBehaviour
{
    public float speed = 7f;
    public float direction = -1f;
    public Rigidbody2D teacher;

     private void Update()
    {
        teacher.velocity = new Vector2(speed * direction, teacher.velocity.y);
        transform.localScale = new Vector3(direction, 1, 1);
    } 

    private void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "Wall")
            direction *= -1f;
    } 



}
